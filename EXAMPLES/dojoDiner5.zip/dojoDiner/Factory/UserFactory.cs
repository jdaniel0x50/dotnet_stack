using System.Collections.Generic;
using System.Linq;
using Dapper;
using System.Data;
using MySql.Data.MySqlClient;
using dojoDiner.Models;
//The following using statements are required for db settings injection:
using Microsoft.Extensions.Options;

namespace dojoDiner.Factory
{
    public class UserFactory : IFactory<User>
    {
        //private string connectionString;
        private readonly IOptions<MySqlOptions> MySqlConfig;
        internal IDbConnection Connection
        {
            get
            {
                // Instead of configuring the MySqlConnection with the connectionString, we now use the MySqlConfig object being passed into the factory via dependency injection, cool!

                //return new MySqlConnection(connectionString);
                return new MySqlConnection(MySqlConfig.Value.ConnectionString);
            }
        }

        public UserFactory(IOptions<MySqlOptions> mySqlConfig)
        {
            // OLD way -- "HARD CODING"
            //connectionString = "server=localhost;userid=root;password=root;port=3306;database=dojodiner;SslMode=None";

            //NEW way -- Dependency injection
            MySqlConfig = mySqlConfig;
        }
        public void Register(RegisterViewModel user)
        {
            using (IDbConnection dbConnection = Connection)
            {
                string query = $"INSERT INTO USER (firstName, lastName, email, password) VALUES ('{user.firstName}', '{user.lastName}', '{user.email}', '{user.regPassword}')";
                
                dbConnection.Open();
                dbConnection.Execute(query, user);
            }
        }
        public IEnumerable<User> GetUserById(string userId)
        {
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                return dbConnection.Query<User>($"SELECT TOP 1 * FROM user where Id = '{userId}'");
            }
        }

        public User GetUserByEmail(string email)
        {
            using (IDbConnection dbConnection = Connection)
            {
                dbConnection.Open();
                return dbConnection.Query<User>($"SELECT * FROM user where email = '{email}'").FirstOrDefault();
            }
        }
    }
}